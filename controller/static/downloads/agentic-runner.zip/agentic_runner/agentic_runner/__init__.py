"""Isolated cloud CLI broker; never receives Home Assistant credentials."""

VERSION = "0.4.0"
